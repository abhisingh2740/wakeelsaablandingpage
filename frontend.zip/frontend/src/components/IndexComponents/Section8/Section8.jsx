import React from "react";
import CarouselM from "./Carousel";
import "./Section8.css";

const Section8 = () => {
  return (
    <div>
      <br />
      <br />
      <br />
      <h1 className="SectionHeads">Hear About us from clients</h1>
      <br />
      <br />

      <CarouselM />
    </div>
  );
};

export default Section8;
